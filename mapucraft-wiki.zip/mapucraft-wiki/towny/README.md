# 🏘️ Towny

¡Bienvenido a la wiki oficial del **Towny** de Mapucraft! Aquí encontrarás información detallada sobre todos los sistemas, mecánicas y contenido de esta modalidad.

¿Tienes dudas o encontraste algo incorrecto? Cuéntanos en el [Discord](https://discord.gg/bRjP5ruEwM).

***

## Contenido

<table data-view="cards"><thead><tr><th></th></tr></thead><tbody>
<tr><td><a href="skills.md">⚡ Skills</a></td></tr>
<tr><td><a href="jobs.md">💼 Jobs</a></td></tr>
<tr><td><a href="encantamientos.md">✨ Encantamientos</a></td></tr>
<tr><td><a href="crafteos.md">🔨 Crafteos Custom</a></td></tr>
<tr><td><a href="dungeons/README.md">🏰 Dungeons</a></td></tr>
<tr><td><a href="eventos/README.md">🎯 Eventos</a></td></tr>
<tr><td><a href="economia/README.md">💰 Economía</a></td></tr>
</tbody></table>
